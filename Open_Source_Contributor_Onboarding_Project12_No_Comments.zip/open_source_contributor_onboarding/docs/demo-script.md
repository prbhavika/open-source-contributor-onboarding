# 5-minute demo script

1. Sign in with `contributor@example.test` / `demo12345`.
2. Browse the seeded Campus Events Toolkit project and its issues.
3. Open **Find my first issue**, enter `react, javascript, testing`, and run matching.
4. Open **Ask the docs** and ask how to run tests. Point out the cited file paths and snapshot version.
5. Draft and save a starter plan. Explain that it is only a proposal and no repository code is run or modified.
6. In Postman, call the health endpoint, issue list, matching, documentation chat and plan endpoint.
7. Show the maintainer workflow using `maintainer@example.test` / `demo12345` and review a plan created by the contributor.
8. Explain the honest limitation: demo snapshot and local AI; live GitHub sync is an optional extension.
