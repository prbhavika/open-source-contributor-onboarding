# Architecture and access model

```text
React (Vite)
  | cookie-authenticated REST calls
  v
Express API ---- Ollama (local chat; optional)
  |
  +---- MongoDB
        Users / Projects / Issues / Snapshots / ContributionPlans / AuditEvents / sessions
```

## Access boundaries
- Public: published projects and their open issue summaries.
- Contributor: own profile, issue interests, own plans, and public repository snapshots.
- Maintainer: project-scoped plan review only for projects listed in their `maintainerIds`.
- Moderator: project verification flag; this does not grant access to private contribution plans.
- All AI/tool inputs are validated with Zod. Acting identity comes from the server session, not request JSON.
- The agent produces a proposal only. It does not run code or write to Git repositories.

## Retrieval path
The snapshot schema supports `embedding` and `embeddingModel` fields for each file. LangChain's `OllamaEmbeddings` is included to generate local embeddings. For Atlas Vector Search, create a Search index on the `snapshots` collection (database `opensource_onboarding`) named `snapshot_vector_index` with this definition:

```json
{
  "fields": [
    { "type": "vector", "path": "files.embedding", "numDimensions": 768, "similarity": "cosine" },
    { "type": "filter", "path": "files.path" },
    { "type": "filter", "path": "projectId" },
    { "type": "filter", "path": "version" }
  ]
}
```

**Important:** `nomic-embed-text` commonly returns 768 dimensions, but verify the actual model output before creating the index. The index definition above is a starting template; MongoDB Atlas vector index behavior for arrays of embedded subdocuments can require flattening each file into its own `chunks` document. For a reliable capstone implementation, use a `chunks` collection with one document per file chunk, fields `projectId`, `snapshotVersion`, `path`, `content`, `embedding`, and `embeddingModel`, then define the vector index over `embedding` (not `files.embedding`). Filter by project and authorization scope before returning content. The current seeded demo remains usable without a vector index and the lexical retrieval fallback is clearly documented.

For the final evaluation, demonstrate both behavior paths: cited source snippets when evidence exists, and a not-enough-information response when it does not. Store the embedding model/version alongside every embedded chunk and re-embed after model changes.
