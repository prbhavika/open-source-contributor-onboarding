# Open Source Contributor Onboarding

A student-focused portal for finding suitable open-source issues, reading a versioned repository snapshot, asking evidence-based setup questions, and drafting a contribution plan for maintainer review.

## Stack
- React + Vite
- Node.js + Express REST API
- MongoDB + Mongoose
- Ollama for local chat and embeddings (no paid AI API)
- Postman collection included

This is a learning/demo implementation. It is not production-ready. Start with seeded demo data and local Ollama; live GitHub sync, email delivery and repository writes are intentionally out of scope.

## Prerequisites
- Node.js 20+
- MongoDB Community locally **or** a MongoDB Atlas free cluster
- Ollama installed locally
- Postman (optional; the collection can also be imported into compatible API clients)

## Quick start
1. Copy `server/.env.example` to `server/.env` and fill in `MONGODB_URI`. Keep secrets out of Git.
2. In a terminal:
   ```bash
   cd server
   npm install
   npm run seed
   npm run dev
   ```
3. In a second terminal, pull a local model (example):
   ```bash
   ollama pull llama3.2
   ollama pull nomic-embed-text
   ollama serve
   ```
   If Ollama is already running as a background service, do not start a second server.
4. In a third terminal:
   ```bash
   cd client
   npm install
   npm run dev
   ```
5. Open the Vite URL shown in the terminal (normally `http://localhost:5173`).

The app has a deterministic fallback for issue matching and starter-plan generation when Ollama is unavailable. AI chat returns a clear error rather than pretending a model answered.

## Demo accounts
The seed script creates these demo users:
- Contributor: `contributor@example.test` / `demo12345`
- Maintainer: `maintainer@example.test` / `demo12345`
- Moderator: `moderator@example.test` / `demo12345`

The seed script marks demo accounts verified. For normal signup, the development verification token is returned in the API response and displayed in the development inbox endpoint. This is only for local demos; do not expose verification tokens in production.

## API and Postman
Import `postman/Open-Source-Contributor-Onboarding.postman_collection.json` into Postman. Set collection variable `baseUrl` to `http://localhost:4000`. Run **Register** then **Read development inbox / verify email** for a fresh account, or use a seeded account. Login stores the session cookie in Postman when cookie handling is enabled.

Key endpoints:
- `GET /api/health`
- `POST /api/auth/register`, `/verify-email`, `/login`, `/logout`, `/forgot-password`, `/reset-password`, `/change-password`
- `GET /api/auth/me`
- `GET /api/projects`, `GET /api/projects/:id/issues`
- `POST /api/issues/match`
- `GET /api/snapshots/:projectId`
- `POST /api/contributor-chat`
- `POST /api/onboarding-agent`
- `POST /api/contribution-plans`, `GET /api/contribution-plans/:id`
- `POST /api/contribution-plans/:id/review`
- `POST /api/issues/:id/interest`
- `POST /api/projects/:id/verification` (moderator)

## What is implemented
- Signup/login/logout, password hashing, server-side Mongo session, email verification demo inbox, password reset demo flow
- Contributor / maintainer / moderator roles and ownership checks
- Seeded projects, issues and versioned documentation snapshot
- Issue matching with a transparent local keyword baseline
- LangChain JS + Ollama embedding support; optional Atlas Vector Search retrieval when embeddings and the index are configured
- Documentation-grounded chat with source file references and a not-enough-evidence response
- Bounded onboarding workflow: find issues → inspect prerequisites/status → draft a plan; no repository writes or code execution
- Contribution plans and maintainer review
- Audit events for important actions
- Postman requests and basic API tests

## Limitations / security notes
This is a capstone starter, not a production deployment. For production, add a real email provider, HTTPS, robust CSRF protection, rate limiting, structured logging, stronger session/cookie configuration, file-upload scanning, moderation workflows, and security review. The development inbox and token-return behavior must be disabled. The local Ollama endpoint should not be exposed publicly. Document upload/import is represented by curated seeded snapshots; arbitrary code is never executed. Atlas Vector Search needs an Atlas free cluster and the index described in `docs/architecture.md`; without that index, the app uses a clearly labeled lexical retrieval fallback.
