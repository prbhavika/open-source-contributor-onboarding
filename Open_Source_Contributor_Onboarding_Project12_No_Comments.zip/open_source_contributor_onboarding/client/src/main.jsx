import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const API = 'http://localhost:4000/api';
async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
function App() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [projectId, setProjectId] = useState('');
  const [issues, setIssues] = useState([]);
  const [tab, setTab] = useState('discover');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ name: '', email: 'contributor@example.test', password: 'demo12345', skills: 'javascript, react, testing' });
  const [authMode, setAuthMode] = useState('login');
  const [question, setQuestion] = useState('How do I run tests before contributing?');
  const [answer, setAnswer] = useState(null);
  const [plan, setPlan] = useState(null);
  const [goal, setGoal] = useState('I want to make a small, tested contribution to this issue.');
  const [matchSkills, setMatchSkills] = useState('react, javascript, testing');
  const [matches, setMatches] = useState([]);

  useEffect(() => {
    request('/projects').then(d => { setProjects(d.projects); if (d.projects[0]) setProjectId(d.projects[0]._id); }).catch(e => setNotice(e.message));
    request('/auth/me').then(d => setUser(d.user)).catch(() => {});
  }, []);
  useEffect(() => {
    if (projectId) request(`/projects/${projectId}/issues`).then(d => setIssues(d.issues)).catch(e => setNotice(e.message));
  }, [projectId]);
  const run = async fn => { setBusy(true); setNotice(''); try { await fn(); } catch (e) { setNotice(e.message); } finally { setBusy(false); } };
  const login = e => { e.preventDefault(); run(async () => {
    if (authMode === 'register') {
      const d = await request('/auth/register', { method: 'POST', body: JSON.stringify({ name: form.name, email: form.email, password: form.password, skills: form.skills.split(',').map(s=>s.trim()).filter(Boolean) }) });
      setNotice(`Account created. Development verification token: ${d.developmentVerificationToken}`);
      setAuthMode('verify'); return;
    }
    if (authMode === 'verify') {
      const t = prompt('Paste the development verification token shown in the message above:');
      await request('/auth/verify-email', { method: 'POST', body: JSON.stringify({ email: form.email, token: t }) });
      setNotice('Email verified. You can now log in.'); setAuthMode('login'); return;
    }
    const d = await request('/auth/login', { method: 'POST', body: JSON.stringify({ email: form.email, password: form.password }) });
    setUser(d.user); setNotice(`Welcome back, ${d.user.name}.`);
  }); };
  const logout = () => run(async () => { await request('/auth/logout', { method: 'POST' }); setUser(null); setNotice('Logged out.'); });
  const match = () => run(async () => {
    const d = await request('/issues/match', { method: 'POST', body: JSON.stringify({ projectId, skills: matchSkills.split(',').map(s=>s.trim()).filter(Boolean), interests: ['open source'], query: matchSkills }) });
    setMatches(d.matches);
  });
  const ask = () => run(async () => { setAnswer(await request('/contributor-chat', { method: 'POST', body: JSON.stringify({ projectId, question }) })); });
  const generatePlan = issue => run(async () => {
    const d = await request('/onboarding-agent', { method: 'POST', body: JSON.stringify({ projectId, skills: matchSkills.split(',').map(s=>s.trim()), timeAvailable: 'A few hours this weekend' }) });
    setPlan(d.proposal);
    if (d.proposal) setNotice('A starter plan was drafted. Review it and save it below; no repository changes were made.');
  });
  const savePlan = () => run(async () => {
    const d = await request('/contribution-plans', { method: 'POST', body: JSON.stringify({ issueId: plan.issueId, projectId, goal, steps: plan.steps, evidence: plan.evidence }) });
    setNotice(`Plan saved with ID ${d.plan._id}. Share this ID with the project maintainer for review.`);
  });

  if (!user) return <main className="auth-shell">
    <section className="brand-panel"><div className="mark">os/</div><p className="eyebrow">COMMUNITY BUILT, ONE STEP AT A TIME</p><h1>Your first open-source contribution starts here.</h1><p>Find a task that fits your skills, understand the repository, and prepare a plan a maintainer can review.</p><div className="mini-note">No automatic code changes. You stay in control.</div></section>
    <section className="auth-card"><div className="eyebrow">CONTRIBUTOR WORKSPACE</div><h2>{authMode === 'register' ? 'Create your account' : authMode === 'verify' ? 'Verify your email' : 'Welcome back'}</h2><p className="muted">Use the demo account to explore the seeded project.</p>
      <form onSubmit={login}>
        {authMode === 'register' && <label>Your name<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required minLength="2"/></label>}
        <label>Email<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required/></label>
        {authMode !== 'verify' && <label>Password<input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required minLength="8"/></label>}
        {authMode === 'register' && <label>Skills, separated by commas<input value={form.skills} onChange={e=>setForm({...form,skills:e.target.value})}/></label>}
        <button disabled={busy}>{busy ? 'Please wait…' : authMode === 'register' ? 'Create account' : authMode === 'verify' ? 'Verify account' : 'Sign in'}</button>
      </form>
      <div className="switch">{authMode !== 'login' ? <button className="text-button" onClick={()=>setAuthMode('login')}>Back to sign in</button> : <><span>New here?</span> <button className="text-button" onClick={()=>setAuthMode('register')}>Create an account</button></>}</div>
      <p className="demo-login">Demo: contributor@example.test / demo12345</p>
      {notice && <div className="notice">{notice}</div>}
    </section>
  </main>;

  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><span className="mark small">os/</span><span>open source<br/><b>onboarding</b></span></div><div className="workspace-label">WORKSPACE</div>
      <button className={tab==='discover'?'nav active':'nav'} onClick={()=>setTab('discover')}>⌕ <span>Discover projects</span></button>
      <button className={tab==='match'?'nav active':'nav'} onClick={()=>setTab('match')}>◇ <span>Find my first issue</span></button>
      <button className={tab==='docs'?'nav active':'nav'} onClick={()=>setTab('docs')}>▤ <span>Ask the docs</span></button>
      <button className={tab==='plan'?'nav active':'nav'} onClick={()=>setTab('plan')}>↗ <span>Starter plan</span></button>
      <div className="sidebar-bottom"><div className="avatar">{user.name.slice(0,1).toUpperCase()}</div><div className="user-meta"><b>{user.name}</b><small>{user.role}</small></div><button className="logout" onClick={logout}>↗</button></div>
    </aside>
    <main className="main-area"><header className="topbar"><div><span className="eyebrow">YOUR CONTRIBUTION JOURNEY</span><h1>{tab==='discover'?'Find a project worth joining':tab==='match'?'Find your first issue':tab==='docs'?'Repository guide': 'Make a starter plan'}</h1></div><div className="status-pill"><span></span> Demo workspace</div></header>
      {notice && <div className="notice top-notice">{notice}</div>}
      <section className="content">
      {tab==='discover' && <><div className="intro-card"><div><div className="eyebrow light">A GOOD PLACE TO START</div><h2>Small tasks. Real contributions.</h2><p>Browse a curated project snapshot and choose an issue that feels manageable. Check prerequisites before you commit.</p></div><div className="intro-art">{"{ }"}<span>first<br/>commit</span></div></div>
        <div className="section-heading"><div><h2>Projects for you</h2><p>Curated demo repositories with versioned documentation.</p></div><span className="count">{projects.length} PROJECT</span></div>
        {projects.map(p=><article className="project-card" key={p._id}><div className="project-icon">CE</div><div className="project-info"><div className="project-title">{p.name} {p.verified && <span className="verified">✓ verified demo</span>}</div><p>{p.description}</p><div className="tags">{p.tags?.map(t=><span key={t}>{t}</span>)}</div><small>Snapshot: {p.snapshotVersion}</small></div><button className="secondary" onClick={()=>{setProjectId(p._id);setTab('match')}}>Explore issues ↗</button></article>)}
        <div className="section-heading"><div><h2>Open issues</h2><p>Choose one to see the prerequisites and suggested first steps.</p></div></div>
        {issues.map(i=><article className="issue-row" key={i._id}><div className="issue-dot">#</div><div className="issue-info"><b>{i.title}</b><p>{i.description}</p><div className="tags">{i.labels?.map(l=><span key={l}>{l}</span>)}<span className={i.status==='open'?'open-tag':'assigned-tag'}>{i.status}</span></div></div><button className="text-button" onClick={()=>{setPlan({issueId:i._id,projectId,title:i.title,steps:i.starterSteps||[],evidence:[{file:'CONTRIBUTING.md',excerpt:'Follow the project contribution checklist.'}]});setTab('plan')}}>View plan →</button></article>)}
      </>}
      {tab==='match' && <div className="two-col"><section className="panel"><div className="eyebrow">ISSUE MATCHING</div><h2>What do you know already?</h2><p>Use skills you are comfortable with. Matches are suggestions, not a promise that an issue is easy.</p><label>Your skills<input value={matchSkills} onChange={e=>setMatchSkills(e.target.value)}/></label><label>Project<select value={projectId} onChange={e=>setProjectId(e.target.value)}>{projects.map(p=><option key={p._id} value={p._id}>{p.name}</option>)}</select></label><button onClick={match} disabled={busy}>Find matching issues</button></section><section><div className="section-heading"><div><h2>Suggested issues</h2><p>Why each one may fit</p></div></div>{matches.map(m=><article className="match-card" key={m.issue._id}><div className="match-score">{Math.round(m.score*100)}<small>match</small></div><div><b>{m.issue.title}</b><p>{m.issue.description}</p><p className="reason">{m.reasons.join(' ')}</p><div className="tags">{m.issue.skills.map(s=><span key={s}>{s}</span>)}</div><button className="text-button" onClick={()=>generatePlan(m.issue)}>Draft a starter plan →</button></div></article>)}</section></div>}
      {tab==='docs' && <div className="two-col"><section className="panel"><div className="eyebrow">REPOSITORY SNAPSHOT</div><h2>Ask a practical question</h2><p>Answers are based on the imported demo documentation. Source paths appear with each answer.</p><label>Project<select value={projectId} onChange={e=>setProjectId(e.target.value)}>{projects.map(p=><option key={p._id} value={p._id}>{p.name}</option>)}</select></label><label>Your question<textarea rows="4" value={question} onChange={e=>setQuestion(e.target.value)}/></label><button onClick={ask} disabled={busy}>Ask repository guide</button></section><section className="answer-panel"><div className="eyebrow">ANSWER WITH EVIDENCE</div>{answer ? <><h2>{answer.grounded?'Here is what the snapshot says':'Not enough evidence yet'}</h2><p>{answer.answer}</p><p className="muted">Snapshot: {answer.snapshotVersion}</p>{answer.sources?.map(s=><div className="source" key={s.file}><span>▤</span><div><b>{s.file}</b><small>{s.section}</small></div></div>)}</> : <div className="empty-state"><div>⌕</div><b>Your answer will appear here</b><p>Ask about setup steps, tests, components or contribution guidelines.</p></div>}</section></div>}
      {tab==='plan' && <div className="plan-layout"><section className="panel plan-main"><div className="eyebrow">CONTRIBUTION DRAFT</div><h2>{plan?.title || 'Build a clear first step'}</h2><p>Use this as a proposal. A maintainer must confirm assignment before you start.</p>{plan ? <><label>What would you like to achieve?<textarea rows="3" value={goal} onChange={e=>setGoal(e.target.value)}/></label><h3>Suggested steps</h3><ol className="steps">{plan.steps.map((s,i)=><li key={i}>{s}</li>)}</ol><h3>Evidence to read</h3>{plan.evidence.map((e,i)=><div className="source" key={i}><span>▤</span><div><b>{e.file}</b><small>{e.excerpt}</small></div></div>)}<button onClick={savePlan} disabled={busy}>Save plan for maintainer review</button></> : <div className="empty-state"><div>↗</div><b>No draft selected</b><p>Choose an issue from the project list or use issue matching to draft a plan.</p><button className="secondary" onClick={()=>setTab('discover')}>Browse issues</button></div>}</section><aside className="guidance"><div className="eyebrow">BEFORE YOU START</div><h3>Good contribution habits</h3><ul><li>Read the setup guide from a clean checkout.</li><li>Ask before taking an issue.</li><li>Keep your change focused.</li><li>Run tests and report what actually passed.</li><li>Never share tokens or credentials.</li></ul><div className="callout">The agent only drafts a plan. It does not run code or modify a repository.</div></aside></div>}
      </section><footer>Built for learning in public <span>·</span> Snapshot-based demo <span>·</span> No paid AI services</footer>
    </main>
  </div>;
}
createRoot(document.getElementById('root')).render(<App />);
