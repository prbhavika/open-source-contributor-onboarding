const base = () => (process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434').replace(/\/$/, '');

export async function embed(text) {
  const response = await fetch(`${base()}/api/embed`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: process.env.OLLAMA_EMBED_MODEL || 'nomic-embed-text', input: text })
  });
  if (!response.ok) throw new Error(`Ollama embeddings returned ${response.status}`);
  const data = await response.json();
  return data.embeddings?.[0] || [];
}
export async function chat(system, prompt) {
  const response = await fetch(`${base()}/api/chat`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: process.env.OLLAMA_CHAT_MODEL || 'llama3.2',
      stream: false,
      messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }]
    })
  });
  if (!response.ok) throw new Error(`Ollama chat returned ${response.status}`);
  const data = await response.json();
  return data.message?.content || '';
}
export function terms(text) {
  return [...new Set(String(text).toLowerCase().match(/[a-z][a-z0-9+#.-]{2,}/g) || [])];
}
export function lexicalScore(query, text) {
  const q = terms(query), t = new Set(terms(text));
  if (!q.length) return 0;
  return q.filter(x => t.has(x)).length / q.length;
}


export async function langchainEmbedder() {
  const { OllamaEmbeddings } = await import('@langchain/ollama');
  return new OllamaEmbeddings({
    model: process.env.OLLAMA_EMBED_MODEL || 'nomic-embed-text',
    baseUrl: process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434'
  });
}
