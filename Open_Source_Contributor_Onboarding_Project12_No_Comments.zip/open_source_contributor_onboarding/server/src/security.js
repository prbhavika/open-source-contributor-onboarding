import crypto from 'node:crypto';
import { AuditEvent } from './models.js';

export const token = () => crypto.randomBytes(24).toString('hex');
export const safeEqual = (a, b) => typeof a === 'string' && typeof b === 'string' &&
  a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));

export function requireAuth(req, res, next) {
  if (!req.session?.userId) return res.status(401).json({ error: 'Please log in first.' });
  next();
}
export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.session?.userId || !roles.includes(req.session.role))
      return res.status(403).json({ error: 'This action is not allowed for your account.' });
    next();
  };
}
export async function audit(req, action, resourceType, resourceId = '', detail = {}) {
  try { await AuditEvent.create({ actorId: req.session?.userId, action, resourceType, resourceId, detail }); }
  catch (e) { console.error('Audit write failed:', e.message); }
}
