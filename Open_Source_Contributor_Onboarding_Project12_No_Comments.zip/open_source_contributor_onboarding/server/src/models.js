import mongoose from 'mongoose';

const { Schema, model } = mongoose;
const userSchema = new Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ['contributor', 'maintainer', 'moderator'], default: 'contributor' },
  verified: { type: Boolean, default: false },
  verificationToken: String,
  resetToken: String,
  resetExpires: Date,
  skills: { type: [String], default: [] },
  interests: { type: [String], default: [] }
}, { timestamps: true });

const projectSchema = new Schema({
  name: { type: String, required: true },
  description: String,
  tags: [String],
  public: { type: Boolean, default: true },
  verified: { type: Boolean, default: true },
  snapshotVersion: String,
  maintainerIds: [{ type: Schema.Types.ObjectId, ref: 'User' }]
}, { timestamps: true });

const issueSchema = new Schema({
  projectId: { type: Schema.Types.ObjectId, ref: 'Project', required: true, index: true },
  title: { type: String, required: true },
  description: String,
  status: { type: String, enum: ['open', 'assigned', 'closed'], default: 'open' },
  skills: [String],
  prerequisites: [String],
  labels: [String],
  starterSteps: [String],
  ownerName: String
}, { timestamps: true });

const snapshotSchema = new Schema({
  projectId: { type: Schema.Types.ObjectId, ref: 'Project', required: true, index: true },
  version: { type: String, required: true },
  files: [{ path: String, content: String, section: String, embedding: { type: [Number], default: undefined }, embeddingModel: String }]
}, { timestamps: true });

const planSchema = new Schema({
  contributorId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  issueId: { type: Schema.Types.ObjectId, ref: 'Issue', required: true },
  projectId: { type: Schema.Types.ObjectId, ref: 'Project', required: true },
  goal: String,
  steps: [String],
  evidence: [{ file: String, excerpt: String }],
  status: { type: String, enum: ['draft', 'submitted', 'needs_changes', 'approved'], default: 'draft' },
  maintainerFeedback: String,
  reviewedBy: { type: Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

const auditSchema = new Schema({
  actorId: { type: Schema.Types.ObjectId, ref: 'User' },
  action: String,
  resourceType: String,
  resourceId: String,
  detail: Schema.Types.Mixed
}, { timestamps: true });

export const User = mongoose.models.User || model('User', userSchema);
export const Project = mongoose.models.Project || model('Project', projectSchema);
export const Issue = mongoose.models.Issue || model('Issue', issueSchema);
export const Snapshot = mongoose.models.Snapshot || model('Snapshot', snapshotSchema);
export const ContributionPlan = mongoose.models.ContributionPlan || model('ContributionPlan', planSchema);
export const AuditEvent = mongoose.models.AuditEvent || model('AuditEvent', auditSchema);
