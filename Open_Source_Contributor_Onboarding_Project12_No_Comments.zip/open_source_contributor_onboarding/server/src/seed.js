import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { User, Project, Issue, Snapshot } from './models.js';

await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/opensource_onboarding');
await Promise.all([User.deleteMany({}), Project.deleteMany({}), Issue.deleteMany({}), Snapshot.deleteMany({})]);
const passwordHash = await bcrypt.hash('demo12345', 12);
const [contributor, maintainer, moderator] = await User.create([
  { name: 'Demo Contributor', email: 'contributor@example.test', passwordHash, role: 'contributor', verified: true, skills: ['javascript', 'react', 'testing'], interests: ['documentation', 'frontend'] },
  { name: 'Demo Maintainer', email: 'maintainer@example.test', passwordHash, role: 'maintainer', verified: true },
  { name: 'Demo Moderator', email: 'moderator@example.test', passwordHash, role: 'moderator', verified: true }
]);
const project = await Project.create({
  name: 'Campus Events Toolkit',
  description: 'A small community project for managing campus event listings and accessible event details.',
  tags: ['javascript', 'react', 'express', 'documentation', 'testing'],
  public: true, verified: true, snapshotVersion: 'demo-snapshot-v1', maintainerIds: [maintainer._id]
});
await Issue.create([
  { projectId: project._id, title: 'Add empty state to event search', description: 'Show a helpful message when a search has no matching events.', status: 'open', skills: ['react', 'javascript', 'css'], prerequisites: ['React component basics', 'Run npm test'], labels: ['good first issue', 'frontend'], starterSteps: ['Find the event search component.', 'Check how results are rendered.', 'Add an empty-state component.', 'Add a test for zero results.'] },
  { projectId: project._id, title: 'Document local development setup', description: 'Clarify install, environment variables and local startup steps.', status: 'open', skills: ['documentation', 'node', 'javascript'], prerequisites: ['Read the README'], labels: ['documentation', 'good first issue'], starterSteps: ['Follow the setup instructions from a clean checkout.', 'List missing or unclear steps.', 'Update the README and verify every command.'] },
  { projectId: project._id, title: 'Add validation tests for event dates', description: 'Cover invalid dates and events whose end date comes before the start date.', status: 'open', skills: ['testing', 'javascript', 'node'], prerequisites: ['Basic test runner knowledge'], labels: ['tests', 'good first issue'], starterSteps: ['Locate event validation.', 'Add boundary test cases.', 'Run the test suite and record results.'] },
  { projectId: project._id, title: 'Improve accessible labels on filters', description: 'Make category and date filters clear to screen-reader users.', status: 'assigned', skills: ['react', 'accessibility'], prerequisites: ['HTML labels and forms'], labels: ['accessibility'], starterSteps: ['Inspect filter controls.', 'Add programmatic labels.', 'Test with keyboard navigation.'], ownerName: 'Another contributor' }
]);
await Snapshot.create({
  projectId: project._id, version: 'demo-snapshot-v1',
  files: [
    { path: 'README.md', section: 'Setup', content: 'Campus Events Toolkit helps student clubs publish event details. Local setup: install Node.js 20+, run npm install, copy .env.example to .env, run npm run dev. Tests run with npm test. Do not commit secrets.' },
    { path: 'CONTRIBUTING.md', section: 'Contribution workflow', content: 'Before opening a contribution, check existing issues, comment that you want to work on the task, and wait for maintainer confirmation. Create a focused branch, explain the change, add tests where appropriate, run npm test, and describe manual checks. Do not include credentials or personal data.' },
    { path: 'src/components/EventSearch.jsx', section: 'Frontend component', content: 'EventSearch owns the search query and renders matching event cards. When there are zero results, render a short empty-state message with a clear action to reset filters. Keep the empty state keyboard accessible.' },
    { path: 'src/validation/eventDates.js', section: 'Date validation', content: 'Event date validation checks that startAt and endAt are valid dates and that endAt is later than startAt. Tests should cover missing dates, invalid date strings, equal dates and end-before-start.' },
    { path: 'docs/testing.md', section: 'Tests', content: 'Run npm test before submitting. Add a focused test for the behavior you changed. Include a test for the empty search result state and date validation boundaries. If a test cannot run, state the reason rather than claiming it passed.' }
  ]
});
console.log('Seed complete. Demo password for all accounts: demo12345');
await mongoose.disconnect();
