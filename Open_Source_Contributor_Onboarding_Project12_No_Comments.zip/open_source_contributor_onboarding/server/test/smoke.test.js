import test from 'node:test';
import assert from 'node:assert/strict';

test('demo configuration uses no paid AI provider', () => {
  assert.equal(process.env.OPENAI_API_KEY, undefined);
});
test('API route contract includes health and required authentication endpoints', async () => {
  const fs = await import('node:fs/promises');
  const source = await fs.readFile(new URL('../src/index.js', import.meta.url), 'utf8');
  for (const route of ['/api/health', '/api/auth/register', '/api/auth/verify-email', '/api/auth/login', '/api/auth/forgot-password', '/api/auth/reset-password', '/api/auth/me', '/api/auth/logout', '/api/auth/change-password']) {
    assert.ok(source.includes(route), `Missing route ${route}`);
  }
});
